export const domainPath = "http://74.208.108.4:8000/"
export const itemTypeFrench = {
    "event": "événement",
    "article": "article",
    "web-activity": "activité",
    "google-analytic-report": "Google Analytics rapport"
  }






